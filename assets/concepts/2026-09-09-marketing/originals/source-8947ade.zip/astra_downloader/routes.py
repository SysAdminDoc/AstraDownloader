"""HTTP route and loopback server boundary for Astra Downloader."""

import hmac
import queue
import threading
import time
import traceback
from collections import deque
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

from flask import Flask, jsonify, request

# Astra Deck sends its endpoint challenge in this header (and as ?challenge=).
ENDPOINT_CHALLENGE_HEADER = "X-MDL-Endpoint-Challenge"
from werkzeug.exceptions import HTTPException, SecurityError

try:
    from ._compat import make_legacy_resolver
except ImportError:  # Flat source-path compatibility.
    from _compat import make_legacy_resolver


__all__ = (
    "create_api", "_ServerAdapter", "_build_wsgi_server", "RateLimiter",
    "RATE_LIMIT_DOWNLOAD_MAX", "RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS",
    "RATE_LIMIT_PICKFOLDER_MAX", "RATE_LIMIT_PICKFOLDER_WINDOW_SECONDS",
    "RATE_LIMIT_HEALTH_MAX", "RATE_LIMIT_HEALTH_WINDOW_SECONDS",
    "CORS_MAX_AGE_SECONDS", "MAX_REQUEST_BYTES", "MAX_RESPONSE_BYTES",
)

_LEGACY_EXPORTS = tuple(
    name for name in __all__
    if name not in {"create_api", "_ServerAdapter", "_build_wsgi_server", "RateLimiter"}
)
_resolve_legacy = make_legacy_resolver(_LEGACY_EXPORTS)

_PUBLIC_RUNTIME_FIELDS = (
    "runtime",
    "installed",
    "version",
    "supported",
    "ejsReady",
    "minVersion",
    "reason",
    "configuredRuntime",
    "canProvisionDeno",
    "ytdlpNeedsRuntime",
    "advice",
    "source",
)

_YOUTUBE_SIGN_IN_WARNING_CODE = "youtube-account-risk"
_YOUTUBE_SIGN_IN_WARNING = (
    "YouTube sign-ins are risky. yt-dlp warns that account use can cause "
    "temporary or permanent bans, and some signed-in sessions can make public "
    "videos unplayable. Use cookies only for account-required videos, keep a "
    "5 to 10 second pause, and retry public videos signed out."
)
_YOUTUBE_SIGN_IN_WARNING_URL = (
    "https://github.com/yt-dlp/yt-dlp/wiki/Extractors#exporting-youtube-cookies"
)


def _public_runtime_status(status):
    """Return the runtime capability contract without local filesystem data."""
    if not isinstance(status, dict):
        return {}
    return {key: status[key] for key in _PUBLIC_RUNTIME_FIELDS if key in status}


class RateLimiter:
    """Thread-safe sliding-window limiter with an injectable monotonic clock."""

    def __init__(self, max_events, window_seconds, clock=None):
        self.max_events = max_events
        self.window_seconds = window_seconds
        self._clock = clock or time.monotonic
        self._lock = threading.Lock()
        self._buckets = {}

    def allow(self, key="default"):
        """Return ``(allowed, retry_after_seconds)`` for one bucket."""
        now = self._clock()
        cutoff = now - self.window_seconds
        with self._lock:
            events = self._buckets.setdefault(key, deque())
            while events and events[0] < cutoff:
                events.popleft()
            if len(events) >= self.max_events:
                retry = max(0.0, self.window_seconds - (now - events[0]))
                return False, retry
            events.append(now)
            return True, 0.0


class _ServerAdapter:
    """Uniform run/stop contract over waitress and Werkzeug servers."""

    def __init__(self, backend, server):
        self.backend = backend
        self._server = server

    def run(self):
        if self.backend == "waitress":
            self._server.run()
        else:
            self._server.serve_forever()

    def stop(self):
        try:
            if self.backend == "waitress":
                self._server.close()
            else:
                self._server.shutdown()
                self._server.server_close()
        except Exception:
            # reason: server teardown is best-effort from the GUI thread
            pass


def _build_wsgi_server(chosen_port, api, waitress_factory=None, werkzeug_factory=None):
    """Build a loopback-only WSGI server, preferring waitress.

    Factories are injectable so backend selection, bind errors, and teardown
    remain testable without opening sockets or starting server threads.
    """

    if waitress_factory is None:
        try:
            from waitress.server import create_server as waitress_factory
        except ImportError:
            waitress_factory = None

    if callable(waitress_factory):
        server = waitress_factory(
            api,
            host="127.0.0.1",
            port=chosen_port,
            threads=8,
            ident="Astra Downloader",
        )
        return _ServerAdapter("waitress", server)

    if werkzeug_factory is None:
        from werkzeug.serving import make_server as werkzeug_factory
    try:
        server = werkzeug_factory("127.0.0.1", chosen_port, api, threaded=True)
    except SystemExit as exc:
        raise OSError(f"Werkzeug aborted while binding port {chosen_port}") from exc
    return _ServerAdapter("werkzeug", server)


_REQUIRED_API_DEPENDENCIES = frozenset({
    'APP_NAME',
    'APP_VERSION',
    'CORS_MAX_AGE_SECONDS',
    'DEFAULT_CONFIG',
    'MAX_REQUEST_BYTES',
    'MAX_RESPONSE_BYTES',
    'RATE_LIMIT_DOWNLOAD_MAX',
    'RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS',
    'RATE_LIMIT_PICKFOLDER_MAX',
    'RATE_LIMIT_PICKFOLDER_WINDOW_SECONDS',
    'RATE_LIMIT_HEALTH_MAX',
    'RATE_LIMIT_HEALTH_WINDOW_SECONDS',
    'RATE_LIMIT_UPDATE_MAX',
    'RATE_LIMIT_UPDATE_WINDOW_SECONDS',
    'RATE_LIMIT_PAIR_MAX',
    'RATE_LIMIT_PAIR_WINDOW_SECONDS',
    'COMPANION_UPDATE_FAILURE_BACKOFF_SECONDS',
    'SERVER_PORT',
    'SERVICE_API_MINIMUM_CLIENT',
    'SERVICE_API_VERSION',
    'SERVICE_ID',
    'YTDLP_PATH',
    '_folder_pick_q',
    '_folder_picker_service',
    '_run_companion_self_update',
    '_run_ytdlp_self_update',
    'allowed_output_roots',
    'check_ffmpeg_capabilities',
    'clamp_int',
    'clean_text',
    'coerce_bool',
    'download_error_payload',
    'get_ffmpeg_version',
    'get_last_deno_provision_error',
    'get_recent_log_entries',
    'get_ytdlp_version',
    'evaluate_sabr_support',
    'evaluate_preflight_checks',
    'get_preflight_ffmpeg_capabilities',
    'get_preflight_output_folder',
    'get_preflight_state_location',
    'get_system_clock_state',
    'get_github_api_budget',
    'describe_media_url_block',
    'is_youtube_url',
    'legacy_health_token_origin_allowlist',
    'paired_extension_origin_allowlist',
    'compute_endpoint_proof',
    'media_url_block_reason',
    'MAX_SITE_LOGIN_COOKIES',
    'normalize_extension_origin',
    'is_extension_origin_shape',
    'pair_browser_extension',
    'normalize_url',
    'probe_javascript_runtime',
    'probe_po_token_provider',
    'provision_deno',
    'lookup_history_url',
    'normalize_history_date',
    'normalize_output_dir',
    'query_history_entries',
    'read_update_recovery_status',
    'validate_download_request_body',
    'write_persistent_log',
})


def create_api(config, dl_manager, history, *, dependencies):
    if not isinstance(dependencies, dict):
        raise TypeError("dependencies must be a dict")
    missing = sorted(set(_REQUIRED_API_DEPENDENCIES) - set(dependencies))
    if missing:
        raise ValueError("Missing API dependencies: " + ", ".join(missing))
    APP_NAME = dependencies['APP_NAME']
    APP_VERSION = dependencies['APP_VERSION']
    CORS_MAX_AGE_SECONDS = dependencies['CORS_MAX_AGE_SECONDS']
    DEFAULT_CONFIG = dependencies['DEFAULT_CONFIG']
    MAX_REQUEST_BYTES = dependencies['MAX_REQUEST_BYTES']
    MAX_RESPONSE_BYTES = dependencies['MAX_RESPONSE_BYTES']
    RATE_LIMIT_DOWNLOAD_MAX = dependencies['RATE_LIMIT_DOWNLOAD_MAX']
    RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS = dependencies['RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS']
    RATE_LIMIT_PICKFOLDER_MAX = dependencies['RATE_LIMIT_PICKFOLDER_MAX']
    RATE_LIMIT_PICKFOLDER_WINDOW_SECONDS = dependencies['RATE_LIMIT_PICKFOLDER_WINDOW_SECONDS']
    RATE_LIMIT_HEALTH_MAX = dependencies['RATE_LIMIT_HEALTH_MAX']
    RATE_LIMIT_HEALTH_WINDOW_SECONDS = dependencies['RATE_LIMIT_HEALTH_WINDOW_SECONDS']
    RATE_LIMIT_UPDATE_MAX = dependencies['RATE_LIMIT_UPDATE_MAX']
    RATE_LIMIT_UPDATE_WINDOW_SECONDS = dependencies['RATE_LIMIT_UPDATE_WINDOW_SECONDS']
    RATE_LIMIT_PAIR_MAX = dependencies['RATE_LIMIT_PAIR_MAX']
    RATE_LIMIT_PAIR_WINDOW_SECONDS = dependencies['RATE_LIMIT_PAIR_WINDOW_SECONDS']
    COMPANION_UPDATE_FAILURE_BACKOFF_SECONDS = dependencies['COMPANION_UPDATE_FAILURE_BACKOFF_SECONDS']
    SERVER_PORT = dependencies['SERVER_PORT']
    SERVICE_API_VERSION = dependencies['SERVICE_API_VERSION']
    SERVICE_API_MINIMUM_CLIENT = dependencies['SERVICE_API_MINIMUM_CLIENT']
    SERVICE_ID = dependencies['SERVICE_ID']
    YTDLP_PATH = dependencies['YTDLP_PATH']
    _folder_pick_q = dependencies['_folder_pick_q']
    _folder_picker_service = dependencies['_folder_picker_service']
    _run_companion_self_update = dependencies['_run_companion_self_update']
    _run_ytdlp_self_update = dependencies['_run_ytdlp_self_update']
    allowed_output_roots = dependencies['allowed_output_roots']
    check_ffmpeg_capabilities = dependencies['check_ffmpeg_capabilities']
    clamp_int = dependencies['clamp_int']
    clean_text = dependencies['clean_text']
    coerce_bool = dependencies['coerce_bool']
    download_error_payload = dependencies['download_error_payload']
    get_ffmpeg_version = dependencies['get_ffmpeg_version']
    get_last_deno_provision_error = dependencies['get_last_deno_provision_error']
    get_recent_log_entries = dependencies['get_recent_log_entries']
    get_ytdlp_version = dependencies['get_ytdlp_version']
    evaluate_sabr_support = dependencies['evaluate_sabr_support']
    evaluate_preflight_checks = dependencies['evaluate_preflight_checks']
    get_preflight_ffmpeg_capabilities = dependencies['get_preflight_ffmpeg_capabilities']
    get_github_api_budget = dependencies['get_github_api_budget']
    describe_media_url_block = dependencies['describe_media_url_block']
    is_youtube_url = dependencies['is_youtube_url']
    legacy_health_token_origin_allowlist = dependencies['legacy_health_token_origin_allowlist']
    paired_extension_origin_allowlist = dependencies['paired_extension_origin_allowlist']
    media_url_block_reason = dependencies['media_url_block_reason']
    MAX_SITE_LOGIN_COOKIES = dependencies['MAX_SITE_LOGIN_COOKIES']
    normalize_extension_origin = dependencies['normalize_extension_origin']
    is_extension_origin_shape = dependencies['is_extension_origin_shape']
    pair_browser_extension = dependencies['pair_browser_extension']
    normalize_url = dependencies['normalize_url']
    probe_javascript_runtime = dependencies['probe_javascript_runtime']
    probe_po_token_provider = dependencies['probe_po_token_provider']
    provision_deno = dependencies['provision_deno']
    lookup_history_url = dependencies['lookup_history_url']
    normalize_history_date = dependencies['normalize_history_date']
    normalize_output_dir = dependencies['normalize_output_dir']
    query_history_entries = dependencies['query_history_entries']
    read_update_recovery_status = dependencies['read_update_recovery_status']
    validate_download_request_body = dependencies['validate_download_request_body']
    write_persistent_log = dependencies['write_persistent_log']
    subscription_manager = dependencies.get('subscription_manager')
    youtube_sign_in_warning_delivered = bool(
        config.get("YouTubeSignInRiskNoticeShown", False)
    )
    youtube_sign_in_warning_lock = threading.Lock()

    api = Flask(__name__)
    api.logger.disabled = True
    import logging
    logging.getLogger('werkzeug').disabled = True
    # v1.5.1 EI12: cap request bodies BEFORE any route handler sees them.
    # The error handlers below keep Flask's rejection in the same JSON/CORS
    # contract as an ordinary route response.
    api.config['MAX_CONTENT_LENGTH'] = MAX_REQUEST_BYTES
    api.config['TRUSTED_HOSTS'] = ['127.0.0.1', 'localhost', '[::1]']

    # v1.2.0: token-bucket rate limit on /download. Other endpoints are
    # cheap and read-only; we don't limit them (local-only service, no
    # realistic DoS vector beyond /download work queue).
    download_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_DOWNLOAD_MAX,
        window_seconds=RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS,
    )
    pickfolder_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_PICKFOLDER_MAX,
        window_seconds=RATE_LIMIT_PICKFOLDER_WINDOW_SECONDS,
    )
    health_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_HEALTH_MAX,
        window_seconds=RATE_LIMIT_HEALTH_WINDOW_SECONDS,
    )
    subscription_scan_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_DOWNLOAD_MAX,
        window_seconds=RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS,
    )
    companion_update_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_UPDATE_MAX,
        window_seconds=RATE_LIMIT_UPDATE_WINDOW_SECONDS,
    )
    pair_rate_limiter = RateLimiter(
        max_events=RATE_LIMIT_PAIR_MAX,
        window_seconds=RATE_LIMIT_PAIR_WINDOW_SECONDS,
    )
    companion_update_backoff_lock = threading.Lock()
    companion_update_backoff = {'until': 0.0}

    def companion_update_gate():
        now = time.monotonic()
        with companion_update_backoff_lock:
            retry_after = max(0.0, companion_update_backoff['until'] - now)
        if retry_after:
            return False, retry_after, 'update-backoff'
        allowed, retry_after = companion_update_rate_limiter.allow('companion-update')
        return allowed, retry_after, 'update-rate-limited'

    def record_companion_update_result(result):
        now = time.monotonic()
        if result.get('ok'):
            with companion_update_backoff_lock:
                companion_update_backoff['until'] = 0.0
            return
        if result.get('error_code') in {'downloads-in-flight', 'update-in-progress'}:
            return
        with companion_update_backoff_lock:
            companion_update_backoff['until'] = max(
                companion_update_backoff['until'],
                now + COMPANION_UPDATE_FAILURE_BACKOFF_SECONDS,
            )

    def check_auth():
        provided = request.headers.get("X-Auth-Token", "")
        token = config.get("ServerToken")
        return bool(token and provided and hmac.compare_digest(str(provided), str(token)))

    def request_json_object():
        body = request.get_json(silent=True)
        if body is None:
            return {}, None
        if not isinstance(body, dict):
            return None, "Request body must be a JSON object."
        return body, None

    def is_allowed_extension_origin(origin):
        normalized = normalize_extension_origin(origin)
        origins = legacy_health_token_origin_allowlist(config)
        return bool(normalized and normalized in origins)

    def is_paired_extension_origin(origin):
        """True once this Origin completed the /pair-extension handshake.

        Pairing already put the ID in the native-host allowlist, so the token
        is reachable over the native channel anyway; recognising the paired
        Origin here only removes the requirement that native messaging work.
        """
        normalized = normalize_extension_origin(origin)
        origins = paired_extension_origin_allowlist(config)
        return bool(normalized and normalized in origins)

    # Flask owns the primary DNS-rebinding boundary through TRUSTED_HOSTS.
    # Keep one canonical-authority check because Werkzeug 3.1 treats every
    # bracketed IPv6 literal as equivalent while matching a trusted `[::1]`.
    def is_allowed_host():
        authority = request.environ.get('HTTP_HOST', '')
        if not isinstance(authority, str) or not authority:
            return False
        if authority != authority.strip():
            return False
        try:
            parsed = urlsplit(f'//{authority}')
            hostname = parsed.hostname
            port = parsed.port
        except (TypeError, ValueError):
            return False
        if any((
            parsed.scheme, parsed.path, parsed.query, parsed.fragment,
            parsed.username is not None, parsed.password is not None,
        )):
            return False
        if hostname not in {'127.0.0.1', 'localhost', '::1'}:
            return False
        canonical_host = '[::1]' if hostname == '::1' else hostname
        lowered = authority.casefold()
        if port is None:
            return lowered == canonical_host
        prefix = canonical_host + ':'
        port_text = lowered[len(prefix):] if lowered.startswith(prefix) else ''
        return bool(
            port_text
            and port_text.isascii()
            and port_text.isdecimal()
            and 1 <= port <= 65535
        )

    def registered_cors_methods():
        methods = set()
        for rule in api.url_map.iter_rules():
            if rule.endpoint != 'static':
                methods.update(rule.methods or ())
        methods.discard('HEAD')
        priority = {'GET': 0, 'POST': 1, 'PATCH': 2, 'DELETE': 3, 'OPTIONS': 4}
        return ','.join(sorted(
            methods,
            key=lambda method: (priority.get(method, len(priority)), method),
        ))

    def cors_response(data, status=200, extra_headers=None, *, allow_origin=None):
        resp = jsonify(data)
        resp.status_code = status
        # v1.5.1 EI12: outgoing-payload size guard. Replace oversized
        # bodies with a 413 error response — the user-facing API
        # contract is "small JSON responses only"; a 10 MB ceiling
        # never trips for any current endpoint but stops a future
        # /streamlinks / /logs surface from streaming megabytes
        # through the Flask process unnoticed.
        try:
            body_len = len(resp.get_data())
        except Exception:
            # reason: get_data may fail on a non-bytes response; treat as
            # within-bound and let the wire layer surface any anomaly.
            body_len = 0
        if body_len > MAX_RESPONSE_BYTES:
            resp = jsonify({
                "error": "Response body exceeds the {} byte limit ({} bytes built).".format(
                    MAX_RESPONSE_BYTES, body_len
                )
            })
            resp.status_code = 413
        origin = request.headers.get("Origin", "")
        reflected = allow_origin or (origin if is_allowed_extension_origin(origin) else "")
        if reflected:
            resp.headers["Access-Control-Allow-Origin"] = reflected
            resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Methods"] = registered_cors_methods()
        resp.headers["Access-Control-Allow-Headers"] = (
            "Content-Type,X-Auth-Token,X-MDL-Api,X-MDL-Client,"
            "X-MDL-Token,X-MDL-Token-Source," + ENDPOINT_CHALLENGE_HEADER
        )
        # v1.2.0: cache preflight for 10 minutes. Multi-video downloads
        # previously re-negotiated OPTIONS on every POST /download.
        resp.headers["Access-Control-Max-Age"] = str(CORS_MAX_AGE_SECONDS)
        # v1.4.0 (NX11): Defense-in-depth against intermediary caching of
        # auth-bearing responses. CVE-2026-27205 specifically targets
        # Flask session cookies via the `in` operator; Astra Downloader
        # doesn't use Flask sessions (X-Auth-Token bearer model only),
        # so the CVE is structurally inapplicable — but the same class
        # of leak applies to any auth-bearing response cached by an
        # intermediary. `no-store` is the strongest no-cache directive
        # and is the right default for a local REST API that serves
        # tokenized payloads. Also signal `Vary: Cookie` so any future
        # cookie-bearing variant cannot land without explicit review.
        resp.headers["Cache-Control"] = "no-store"
        existing_vary = resp.headers.get("Vary", "")
        vary_tokens = {v.strip() for v in existing_vary.split(",") if v.strip()}
        vary_tokens.add("Cookie")
        resp.headers["Vary"] = ", ".join(sorted(vary_tokens))
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        if extra_headers:
            for k, v in extra_headers.items():
                resp.headers[k] = v
        return resp

    def log_api_error(label, error):
        try:
            write_persistent_log(
                f"{label}: {type(error).__name__}: {error}\n{traceback.format_exc()}"
            )
        except Exception:
            # reason: logging must not turn an already-safe JSON error response
            # into a second exception when the log volume is unavailable.
            pass

    @api.errorhandler(413)
    def handle_request_too_large(error):
        log_api_error("API request rejected because its body was too large", error)
        return cors_response({
            "error": f"Request body exceeds the {MAX_REQUEST_BYTES} byte limit.",
            "code": "request-too-large",
        }, 413)

    @api.errorhandler(HTTPException)
    def handle_http_error(error):
        if error.code == 413:
            return handle_request_too_large(error)
        if isinstance(error, SecurityError):
            return cors_response({
                "error": "Invalid Host header",
                "code": "invalid-host",
            }, 421)
        return cors_response({
            "error": error.description or "The request could not be completed.",
            "code": f"http-{error.code or 500}",
        }, error.code or 500)

    @api.errorhandler(Exception)
    def handle_unexpected_error(error):
        if isinstance(error, HTTPException):
            return handle_http_error(error)
        log_api_error("Unhandled API exception", error)
        return cors_response({
            "error": "Astra Downloader could not complete the request.",
            "code": "internal-server-error",
        }, 500)

    def client_api_version():
        """The wire version the caller claims, or None when it says nothing.

        Astra Deck does not send this yet, so absence must keep behaving
        exactly as before. A client that does send it gets a named refusal
        instead of a slow drift into wrong answers.
        """
        raw = clean_text(request.headers.get("X-MDL-Api", ""), "", 16)
        if not raw:
            return None
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    @api.before_request
    def guard_request():
        # Reject DNS-rebinding probes before any route handler sees them.
        if not is_allowed_host():
            return cors_response({"error": "Invalid Host header"}, 421)
        # A version handshake only helps if a mismatch is named. /health is
        # exempt so an out-of-date client can still read the numbers it needs
        # to explain itself to the user.
        claimed = client_api_version()
        if (
            claimed is not None
            and request.path not in {'/health', '/pair-extension'}
            and claimed < SERVICE_API_MINIMUM_CLIENT
        ):
            return cors_response({
                "error": (
                    f"This Astra Deck speaks API {claimed}; Astra Downloader "
                    f"{APP_VERSION} needs at least {SERVICE_API_MINIMUM_CLIENT}."
                ),
                "code": "client-api-too-old",
                "api": SERVICE_API_VERSION,
                "minimumClientApi": SERVICE_API_MINIMUM_CLIENT,
                "remediation": "Update the Astra Deck browser extension.",
            }, 426)
        if request.method == 'OPTIONS':
            origin = request.headers.get("Origin", "")
            allow = None
            if is_allowed_extension_origin(origin):
                allow = origin
            elif request.path in {'/pair-extension', '/identity'} and is_extension_origin_shape(origin):
                allow = normalize_extension_origin(origin)
            return cors_response({"ok": True}, allow_origin=allow)

    context = SimpleNamespace(
        config=config,
        dl_manager=dl_manager,
        history=history,
        subscription_manager=subscription_manager,
        youtube_sign_in_warning_delivered=youtube_sign_in_warning_delivered,
        youtube_sign_in_warning_lock=youtube_sign_in_warning_lock,
        download_rate_limiter=download_rate_limiter,
        pickfolder_rate_limiter=pickfolder_rate_limiter,
        health_rate_limiter=health_rate_limiter,
        subscription_scan_rate_limiter=subscription_scan_rate_limiter,
        pair_rate_limiter=pair_rate_limiter,
        companion_update_gate=companion_update_gate,
        record_companion_update_result=record_companion_update_result,
        check_auth=check_auth,
        request_json_object=request_json_object,
        is_allowed_extension_origin=is_allowed_extension_origin,
        is_paired_extension_origin=is_paired_extension_origin,
        cors_response=cors_response,
    )
    _register_download_routes(api, context, dependencies)
    _register_queue_routes(api, context, dependencies)
    _register_subscriptions_routes(api, context, dependencies)
    _register_site_logins_routes(api, context, dependencies)
    _register_system_routes(api, context, dependencies)
    return api


def _register_download_routes(api, context, dependencies):
    """Register download, playlist, format, status, and history routes."""
    config = context.config
    dl_manager = context.dl_manager
    history = context.history
    subscription_manager = context.subscription_manager
    download_rate_limiter = context.download_rate_limiter
    check_auth = context.check_auth
    cors_response = context.cors_response
    clamp_int = dependencies["clamp_int"]
    clean_text = dependencies["clean_text"]
    download_error_payload = dependencies["download_error_payload"]
    describe_media_url_block = dependencies["describe_media_url_block"]
    is_youtube_url = dependencies["is_youtube_url"]
    media_url_block_reason = dependencies["media_url_block_reason"]
    MAX_SITE_LOGIN_COOKIES = dependencies["MAX_SITE_LOGIN_COOKIES"]
    normalize_url = dependencies["normalize_url"]
    probe_javascript_runtime = dependencies["probe_javascript_runtime"]
    lookup_history_url = dependencies["lookup_history_url"]
    normalize_history_date = dependencies["normalize_history_date"]
    query_history_entries = dependencies["query_history_entries"]
    validate_download_request_body = dependencies["validate_download_request_body"]

    @api.route('/download', methods=['POST'])
    def download():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        # v1.2.0: rate limit BEFORE we do any body parsing or normalization so
        # a burst can't burn CPU on 10k rejected requests.
        allowed, retry_after = download_rate_limiter.allow('download')
        if not allowed:
            return cors_response(
                {"error": "Too many download requests in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        body, body_err, body_code = validate_download_request_body(request.get_json(silent=True))
        if body_err:
            payload = {"error": body_err}
            if body_code:
                payload["code"] = body_code
            return cors_response(payload, 400)
        url, url_err = normalize_url(body['url'])
        if url_err:
            return cors_response({"error": url_err}, 400)

        # SSRF hardening: v1.8.0 opened the companion to every site yt-dlp
        # supports, so the old YouTube-only allowlist no longer applies — but
        # its actual job does. `normalize_url` only checks scheme+netloc, so
        # without this a caller holding the token could point yt-dlp (and the
        # attached cookie jar) at internal/LAN/cloud-metadata hosts. The
        # private-network denylist enforces that here, at the trust boundary,
        # rather than in the extension (an untrusted boundary).
        block_reason = media_url_block_reason(url)
        if block_reason:
            return cors_response(
                {
                    "error": describe_media_url_block(block_reason),
                    "code": block_reason,
                },
                400,
            )

        # Runtime capability hard gate — YouTube only. yt-dlp needs an external
        # JavaScript runtime to solve YouTube's n/sig challenges; no other
        # extractor does, so refusing a Reddit or X download because Deno is
        # missing would block a capability that works fine without it.
        # Presence is insufficient for YouTube: downloads require a supported
        # version and a successful EJS execution probe.
        runtime = probe_javascript_runtime(
            configured_runtime=config.get('JavaScriptRuntime', 'auto')
        )
        runtime_usable = runtime.get('supported') is True and runtime.get('ejsReady') is True
        if is_youtube_url(url) and runtime.get('ytdlpNeedsRuntime') and not runtime_usable:
            reason = runtime.get('reason')
            if reason == 'runtime-not-installed':
                error_code = 'js-runtime-missing'
            elif reason == 'runtime-version-below-security-floor':
                error_code = 'js-runtime-security-floor'
            elif reason == 'runtime-version-unsupported':
                error_code = 'js-runtime-unsupported'
            elif reason in {'runtime-version-unparseable', 'runtime-probe-failed'}:
                error_code = 'js-runtime-unverified'
            else:
                error_code = 'ejs-runtime-not-ready'
            advice = runtime.get('advice') or 'Configure a supported JavaScript runtime and retry.'
            payload = download_error_payload(
                error_code,
                error=(
                    "yt-dlp requires a verified JavaScript runtime to solve "
                    "YouTube's signature challenges. " + advice
                ),
                advice=advice,
            )
            return cors_response(
                payload,
                422,
            )

        raw_cookies = body.get('cookies')
        cookies = raw_cookies if isinstance(raw_cookies, list) else None
        # Cap the cookie list so a hostile extension context can't cause the
        # server to write a multi-megabyte cookie jar. The bound is the same
        # one the sign-in store enforces: a hardcoded 200 here meant a jar the
        # store accepted whole was silently halved on the download path, and
        # the only symptom was yt-dlp failing to authenticate.
        cookies_truncated = False
        if cookies is not None and len(cookies) > MAX_SITE_LOGIN_COOKIES:
            cookies = cookies[:MAX_SITE_LOGIN_COOKIES]
            cookies_truncated = True
        dl_id, err = dl_manager.start_download(
            url=url,
            audio_only=body.get('audioOnly'),
            fmt=body.get('format'),
            quality=body.get('quality', 'best'),
            output_dir=body.get('outputDir'),
            title=body.get('title'),
            output_name=body.get('outputName'),
            referer=body.get('referer'),
            cookies=cookies,
            section=body.get('section'),
            playlist_items=body.get('playlistItems'),
            video_password=body.get('videoPassword'),
            probe_size=True,
        )
        if err:
            error_code = getattr(err, 'error_code', '')
            if error_code == 'insufficient-disk-space':
                payload = getattr(err, 'payload', None)
                if not isinstance(payload, dict):
                    payload = download_error_payload(
                        'insufficient-disk-space', error=str(err)
                    )
                return cors_response(payload, 507)
            if 'queue is full' in err.lower():
                return cors_response({
                    "error": err,
                    "code": "queue-full",
                    "capacity": dl_manager.capacity(),
                    "remediation": (
                        "Cancel a pending item or wait for a running download to finish, "
                        "then retry."
                    ),
                }, 429)
            if 'incompatible astra downloader version' in err.lower():
                return cors_response({
                    "error": err,
                    "code": "queue-schema-incompatible",
                    "remediation": (
                        "Update Astra Downloader, or delete the pending "
                        "download-queue.json file to start a fresh queue."
                    ),
                }, 503)
            if 'could not save' in err.lower():
                return cors_response({"error": err, "code": "queue-persistence-failed"}, 503)
            return cors_response({"error": err}, 400)
        status_value = dl_manager.status_of(dl_id, default='pending')
        payload = {
            "id": dl_id,
            "status": status_value,
            "capacity": dl_manager.capacity(),
        }
        if cookies_truncated:
            # Say so rather than letting the caller discover it as an
            # authentication failure with nothing pointing at the cause.
            payload["cookiesTruncated"] = MAX_SITE_LOGIN_COOKIES
        return cors_response(payload)

    @api.route('/playlist', methods=['POST'])
    def playlist():
        if not check_auth():
            return cors_response({
                "error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."
            }, 401)
        allowed, retry_after = download_rate_limiter.allow('playlist')
        if not allowed:
            return cors_response(
                {"error": "Too many playlist previews in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        body = request.get_json(silent=True)
        if not isinstance(body, dict) or not isinstance(body.get('url'), str):
            return cors_response({"error": "Missing playlist URL."}, 400)
        url, url_err = normalize_url(body['url'])
        if url_err:
            return cors_response({"error": url_err}, 400)
        block_reason = media_url_block_reason(url)
        if block_reason:
            return cors_response({
                "error": describe_media_url_block(block_reason),
                "code": block_reason,
            }, 400)
        result, err = dl_manager.preview_playlist(url)
        if err:
            if err == getattr(dl_manager, 'PLAYLIST_BUSY_MESSAGE', None):
                return cors_response(
                    {"error": err, "code": "playlist-busy"},
                    429,
                    extra_headers={"Retry-After": "5"},
                )
            status_code = 400 if 'playlist URL' in err else 502
            return cors_response({
                "error": err,
                "code": "invalid-playlist-url" if status_code == 400 else "playlist-unavailable",
            }, status_code)
        return cors_response(result)

    @api.route('/formats', methods=['POST'])
    def formats():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        allowed, retry_after = download_rate_limiter.allow('formats')
        if not allowed:
            return cors_response(
                {"error": "Too many format requests in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        body = request.get_json(silent=True)
        if not isinstance(body, dict) or not isinstance(body.get('url'), str):
            return cors_response({"error": "Missing video URL."}, 400)
        url, url_err = normalize_url(body['url'])
        if url_err:
            return cors_response({"error": url_err}, 400)
        # Same trust boundary as /download — never point yt-dlp (and any
        # attached cookie jar) at private-network hosts.
        block_reason = media_url_block_reason(url)
        if block_reason:
            return cors_response(
                {"error": describe_media_url_block(block_reason), "code": block_reason},
                400,
            )
        result, err = dl_manager.list_formats(url)
        if err:
            if err == getattr(dl_manager, 'FORMATS_BUSY_MESSAGE', None):
                # All probe slots are occupied — a retryable condition, not
                # an extraction failure.
                return cors_response(
                    {"error": err, "code": "formats-busy"},
                    429,
                    extra_headers={"Retry-After": "5"},
                )
            return cors_response({"error": err, "code": "formats-unavailable"}, 502)
        return cors_response(result)

    @api.route('/status/<dl_id>')
    def status(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        payload = dl_manager.snapshot_of(dl_id)
        if payload is None:
            return cors_response({"error": "Download no longer exists in the active queue."}, 404)
        return cors_response(payload)

    @api.route('/history')
    def hist():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        raw_limit = request.args.get('limit', '50')
        raw_offset = request.args.get('offset', '0')
        try:
            limit = int(raw_limit)
        except (TypeError, ValueError):
            return cors_response({
                "error": "History limit must be an integer.",
                "code": "invalid-limit",
            }, 400)
        try:
            offset = int(raw_offset)
        except (TypeError, ValueError):
            return cors_response({
                "error": "History offset must be an integer.",
                "code": "invalid-offset",
            }, 400)
        limit = clamp_int(limit, 50, 1, 500)
        offset = clamp_int(offset, 0, 0, 500)
        sort = request.args.get('sort', 'newest').strip().lower()
        if sort not in {'newest', 'oldest'}:
            return cors_response({
                "error": "History sort must be newest or oldest.",
                "code": "invalid-sort",
            }, 400)
        # strptime alone accepted 2026-8-1 and then let the text comparison
        # in query_history_entries hide every row, with a 200 and an empty
        # page as the only symptom. Normalise to the padded form the rows
        # carry, and range-check that.
        date_from = normalize_history_date(request.args.get('dateFrom', ''))
        date_to = normalize_history_date(request.args.get('dateTo', ''))
        for key, value in (('dateFrom', date_from), ('dateTo', date_to)):
            if value is None:
                return cors_response({
                    "error": f"History {key} must use YYYY-MM-DD.",
                    "code": "invalid-date",
                }, 400)
        if date_from and date_to and date_from > date_to:
            return cors_response({
                "error": "History dateFrom cannot be after dateTo.",
                "code": "invalid-date-range",
            }, 400)
        history_entries = history.load()
        archive_entries = None
        if subscription_manager is not None:
            # Prefer the scalar projection over the full deep copy — see
            # SubscriptionStore.archive_history_view.
            archive_reader = (
                getattr(subscription_manager, 'archive_history_view', None)
                or getattr(subscription_manager, 'archive_entries', None)
            )
            if callable(archive_reader):
                try:
                    archive_entries = archive_reader()
                except Exception:
                    # reason: history is the answer here; an unreadable subscription archive drops the archive column, not the page
                    archive_entries = None
        query_text = clean_text(request.args.get('q'), '', 200)
        requested_url = clean_text(request.args.get('url'), '', 4096)
        result = query_history_entries(
            history_entries,
            query=query_text or requested_url,
            status=clean_text(request.args.get('status'), '', 32),
            fmt=clean_text(request.args.get('format'), '', 16),
            date_from=date_from,
            date_to=date_to,
            sort=sort,
            offset=offset,
            limit=limit,
            archive_entries=archive_entries,
        )
        if requested_url:
            result['lookup'] = lookup_history_url(
                history_entries,
                requested_url,
                archive_entries=archive_entries,
            )
        return cors_response(result)

def _register_queue_routes(api, context, dependencies):
    """Register queue control and cancellation routes."""
    dl_manager = context.dl_manager
    check_auth = context.check_auth
    request_json_object = context.request_json_object
    cors_response = context.cors_response
    MAX_SITE_LOGIN_COOKIES = dependencies["MAX_SITE_LOGIN_COOKIES"]

    @api.route('/downloads/<dl_id>/command', methods=['GET'])
    def download_command(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        payload = dl_manager.snapshot_of(dl_id)
        if payload is None:
            return cors_response({"error": "Download no longer exists in the active queue."}, 404)
        return cors_response({
            "id": dl_id,
            "commandArgs": payload.get("commandArgs") or [],
            "command": " ".join(payload.get("commandArgs") or []),
        })

    # NOTE: must not be named `queue` — a nested function named `queue` would
    # shadow the stdlib `queue` module for every sibling closure in create_api
    # (pick_folder uses queue.Queue / queue.Full / queue.Empty).
    @api.route('/queue')
    def queue_endpoint():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        return cors_response(dl_manager.queue_payload())

    @api.route('/queue/pause', methods=['POST'])
    def pause_queue():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        if not dl_manager.pause_intake():
            return cors_response({
                "error": "Could not save the paused queue state. Check disk space and permissions.",
                "code": "queue-persistence-failed",
            }, 503)
        return cors_response({"paused": True, "capacity": dl_manager.capacity()})

    @api.route('/queue/resume', methods=['POST'])
    def resume_queue():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        if not dl_manager.resume_intake():
            return cors_response({
                "error": "Could not save the resumed queue state. Check disk space and permissions.",
                "code": "queue-persistence-failed",
            }, 503)
        return cors_response({"paused": False, "capacity": dl_manager.capacity()})

    def _fresh_cookies_from_body():
        body, body_error = request_json_object()
        if body_error:
            return None, body_error
        raw = body.get('cookies')
        if raw is None:
            return None, None
        if not isinstance(raw, list):
            return None, 'cookies must be a JSON array.'
        return raw[:MAX_SITE_LOGIN_COOKIES], None

    @api.route('/queue/<dl_id>/resume', methods=['POST'])
    def resume_queued_download(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        cookies, cookie_error = _fresh_cookies_from_body()
        if cookie_error:
            return cors_response({"error": cookie_error, "code": "invalid-cookies"}, 400)
        ok, err = dl_manager.resume_download(dl_id, cookies=cookies)
        if not ok:
            if err and 'still finalizing' in err:
                code = 'download-finalizing'
            elif err and 'Fresh YouTube cookies' in err:
                code = 'fresh-auth-required'
            else:
                code = 'queue-resume-rejected'
            status_code = 404 if err and 'no longer exists' in err else 409
            return cors_response({"error": err, "code": code}, status_code)
        return cors_response({"id": dl_id, "resumed": True, "capacity": dl_manager.capacity()})

    @api.route('/queue/<dl_id>/retry', methods=['POST'])
    def retry_queued_download(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        cookies, cookie_error = _fresh_cookies_from_body()
        if cookie_error:
            return cors_response({"error": cookie_error, "code": "invalid-cookies"}, 400)
        ok, err = dl_manager.retry(dl_id, cookies=cookies)
        if not ok:
            if err and 'queue is full' in err.lower():
                return cors_response({
                    "error": err,
                    "code": "queue-full",
                    "capacity": dl_manager.capacity(),
                    "remediation": (
                        "Cancel a pending item or wait for a running download to finish, "
                        "then retry."
                    ),
                }, 429)
            if err and 'still finalizing' in err:
                code = 'download-finalizing'
            elif err and 'Fresh YouTube cookies' in err:
                code = 'fresh-auth-required'
            else:
                code = 'retry-rejected'
            status_code = 404 if err and 'no longer exists' in err else 409
            return cors_response({"error": err, "code": code}, status_code)
        return cors_response({"id": dl_id, "retried": True, "capacity": dl_manager.capacity()})

    @api.route('/queue/<dl_id>/move', methods=['POST'])
    def move_queued_download(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        body, body_error = request_json_object()
        if body_error:
            return cors_response({"error": body_error, "code": "invalid-request-body"}, 400)
        if 'position' not in body:
            return cors_response({"error": "position is required.", "code": "invalid-position"}, 400)
        ok, err = dl_manager.move_pending(dl_id, body.get('position'))
        if not ok:
            status_code = 400 if err and 'integer' in err else 409
            return cors_response({"error": err, "code": "queue-move-rejected"}, status_code)
        return cors_response({"id": dl_id, "moved": True, "queue": dl_manager.queue_payload()})

    @api.route('/cancel/<dl_id>', methods=['DELETE'])
    def cancel(dl_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        exists = dl_manager.exists(dl_id)
        if dl_manager.cancel(dl_id):
            return cors_response({"id": dl_id, "cancelled": True})
        if exists:
            return cors_response({"error": "Download is already finished and cannot be cancelled."}, 409)
        return cors_response({"error": "Download no longer exists in the active queue."}, 404)


def _register_subscriptions_routes(api, context, dependencies):
    """Register subscription collection routes."""
    config = context.config
    allowed_output_roots = dependencies['allowed_output_roots']
    normalize_output_dir = dependencies['normalize_output_dir']
    subscription_manager = context.subscription_manager
    subscription_scan_rate_limiter = context.subscription_scan_rate_limiter
    check_auth = context.check_auth
    request_json_object = context.request_json_object
    cors_response = context.cors_response

    def _subscription_unavailable():
        return cors_response({
            "error": "Scheduled subscriptions are unavailable until Astra Downloader finishes setup.",
            "code": "subscriptions-unavailable",
        }, 503)

    def _subscription_manager_or_error():
        if subscription_manager is None:
            return None, _subscription_unavailable()
        return subscription_manager, None

    def _is_subscription_persistence_error(error):
        text = str(error or "").casefold()
        return any(marker in text for marker in (
            "could not save subscriptions",
            "subscription state was written by a newer",
            "subscription state schema is incompatible",
            "could not reset subscription retry state",
            "could not save scheduled download archive state",
        ))

    def _subscription_error(error, code, status):
        if _is_subscription_persistence_error(error):
            return cors_response({
                "error": error,
                "code": "subscription-persistence-failed",
            }, 503)
        return cors_response({"error": error, "code": code}, status)

    @api.route('/subscriptions', methods=['GET'])
    def subscriptions_list():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        return cors_response(manager.snapshot())

    # A subscription's own delivery choices. Named on the wire the way the
    # record stores them, and every one is optional: an absent field means
    # "use the global setting", which is what every subscription did before
    # schema 2.
    SUBSCRIPTION_DELIVERY_FIELDS = (
        "outputDir", "format", "quality", "outputTemplate", "audioOnly",
        "upgradeIfBetter",
    )

    def _subscription_delivery(body):
        """The delivery fields present in a body, with the folder checked.

        Returns (delivery, error). An unusable folder stored here does not
        fail until the next scan, and then once per video, so the subscription
        reads as configured while delivering nothing.
        """
        present = {
            key: body[key] for key in SUBSCRIPTION_DELIVERY_FIELDS if key in body
        }
        folder = str(present.get("outputDir") or "").strip()
        if folder:
            resolved, error = normalize_output_dir(
                folder,
                config.get("DownloadPath", ""),
                allowed_roots=allowed_output_roots(config),
            )
            if error:
                return None, error
            present["outputDir"] = resolved
        return (present or None), None

    @api.route('/subscriptions', methods=['POST'])
    def subscriptions_create():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        body, body_error = request_json_object()
        if body_error:
            return cors_response({"error": body_error, "code": "invalid-request-body"}, 400)
        allowed = {"url", "intervalMinutes", "enabled", "title",
                   *SUBSCRIPTION_DELIVERY_FIELDS}
        unknown = sorted(set(body) - allowed)
        if unknown:
            return cors_response({
                "error": "Unsupported subscription field(s): " + ", ".join(unknown),
                "code": "invalid-subscription-field",
            }, 400)
        if not isinstance(body.get("url"), str) or not body.get("url", "").strip():
            return cors_response({"error": "A YouTube channel or playlist URL is required.", "code": "invalid-subscription-url"}, 400)
        delivery, delivery_error = _subscription_delivery(body)
        if delivery_error:
            return cors_response({
                "error": delivery_error,
                "code": "invalid-subscription-output-dir",
            }, 400)
        record, error = manager.add_subscription(
            body["url"],
            interval_minutes=body.get("intervalMinutes", 60),
            enabled=body.get("enabled", True),
            title=body.get("title", ""),
            delivery=delivery,
        )
        if error:
            status = 409 if "already configured" in error.lower() else 400
            return _subscription_error(error, "subscription-rejected", status)
        return cors_response(record, 201)

    @api.route('/subscriptions/<subscription_id>', methods=['PATCH'])
    def subscriptions_update(subscription_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        body, body_error = request_json_object()
        if body_error:
            return cors_response({"error": body_error, "code": "invalid-request-body"}, 400)
        allowed = {"url", "intervalMinutes", "enabled", "title",
                   *SUBSCRIPTION_DELIVERY_FIELDS}
        unknown = sorted(set(body) - allowed)
        if unknown or not body:
            return cors_response({
                "error": (
                    "Provide only url, intervalMinutes, enabled, title, or a "
                    "delivery field (" + ", ".join(SUBSCRIPTION_DELIVERY_FIELDS) + ")."
                ),
                "code": "invalid-subscription-field",
            }, 400)
        fields = {}
        if "url" in body:
            fields["url"] = body["url"]
        if "intervalMinutes" in body:
            fields["interval_minutes"] = body["intervalMinutes"]
        if "enabled" in body:
            fields["enabled"] = body["enabled"]
        if "title" in body:
            fields["title"] = body["title"]
        delivery, delivery_error = _subscription_delivery(body)
        if delivery_error:
            return cors_response({
                "error": delivery_error,
                "code": "invalid-subscription-output-dir",
            }, 400)
        if delivery is not None:
            fields["delivery"] = delivery
        record, error = manager.update_subscription(subscription_id, **fields)
        if error:
            status = 404 if "no longer exists" in error.lower() else 400
            return _subscription_error(error, "subscription-update-rejected", status)
        return cors_response(record)

    @api.route('/subscriptions/<subscription_id>/archive', methods=['GET'])
    def subscriptions_archive(subscription_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        try:
            limit = int(request.args.get('limit', 200))
            offset = int(request.args.get('offset', 0))
        except (TypeError, ValueError):
            return cors_response({
                "error": "limit and offset must be whole numbers.",
                "code": "invalid-archive-page",
            }, 400)
        return cors_response(
            manager.archive_page(subscription_id, limit=limit, offset=offset)
        )

    @api.route('/subscriptions/archive/<path:archive_key>', methods=['DELETE'])
    def subscriptions_archive_forget(archive_key):
        """Let one captured item through again on the next scan.

        DELETE on the archive entry, not on the media: the archive records
        what has been taken, and forgetting an entry is the whole of allowing
        a re-download. Nothing on disk is touched.
        """
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        forgotten, error = manager.forget_archive_entry(archive_key)
        if not forgotten:
            status = 404 if "no longer exists" in str(error).lower() else 409
            return _subscription_error(error, "archive-forget-rejected", status)
        return cors_response({"forgotten": True, "key": str(archive_key)})

    @api.route('/subscriptions/<subscription_id>', methods=['DELETE'])
    def subscriptions_delete(subscription_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        removed, error = manager.remove_subscription(subscription_id)
        if error:
            return _subscription_error(error, "subscription-delete-rejected", 404)
        return cors_response({"id": subscription_id, "removed": bool(removed)})

    @api.route('/subscriptions/<subscription_id>/scan', methods=['POST'])
    def subscriptions_scan(subscription_id):
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        manager, response = _subscription_manager_or_error()
        if response is not None:
            return response
        allowed, retry_after = subscription_scan_rate_limiter.allow('subscription-scan')
        if not allowed:
            return cors_response(
                {
                    "error": "Too many subscription scans in a short period. Please wait a moment.",
                    "code": "subscription-scan-rate-limited",
                },
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        result, error = manager.request_scan(subscription_id)
        if error:
            return _subscription_error(error, "subscription-scan-rejected", 404)
        return cors_response(result, 202)


def _register_site_logins_routes(api, context, dependencies):
    """Register the write-only per-site sign-in resource."""
    config = context.config
    dl_manager = context.dl_manager
    youtube_sign_in_warning_delivered = context.youtube_sign_in_warning_delivered
    youtube_sign_in_warning_lock = context.youtube_sign_in_warning_lock
    download_rate_limiter = context.download_rate_limiter
    check_auth = context.check_auth
    cors_response = context.cors_response
    describe_media_url_block = dependencies["describe_media_url_block"]
    is_youtube_url = dependencies["is_youtube_url"]
    media_url_block_reason = dependencies["media_url_block_reason"]
    MAX_SITE_LOGIN_COOKIES = dependencies["MAX_SITE_LOGIN_COOKIES"]
    normalize_url = dependencies["normalize_url"]
    write_persistent_log = dependencies["write_persistent_log"]

    @api.route('/site-logins', methods=['GET', 'POST', 'DELETE'])
    def site_logins():
        """Manage the per-site cookie store used for signed-in downloads.

        GET returns metadata only — site, source, cookie count, expiry. Cookie
        names and values are never readable back out of this endpoint, so a
        token holder cannot turn the store into a credential dump.
        """
        nonlocal youtube_sign_in_warning_delivered
        if not check_auth():
            return cors_response({
                "error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."
            }, 401)
        store = getattr(dl_manager, 'site_logins', None)
        if store is None:
            return cors_response({"error": "Site sign-ins are unavailable.", "code": "site-logins-unavailable"}, 503)

        if request.method == 'GET':
            return cors_response({"sites": store.entries()})

        allowed, retry_after = download_rate_limiter.allow('site-logins')
        if not allowed:
            return cors_response(
                {"error": "Too many site sign-in requests in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        body = request.get_json(silent=True)
        if not isinstance(body, dict) or not isinstance(body.get('site'), str):
            return cors_response({"error": "Missing site address.", "code": "missing-site"}, 400)

        if request.method == 'DELETE':
            removed = store.remove(body['site'])
            return cors_response({"removed": bool(removed)}, 200 if removed else 404)

        # A site sign-in is only meaningful for a site the downloader may
        # actually reach, so it runs through the same URL policy as /download.
        probe_url, probe_error = normalize_url(
            body['site'] if '://' in body['site'] else f"https://{body['site'].strip()}/"
        )
        if probe_error:
            return cors_response({"error": probe_error, "code": "invalid-site"}, 400)
        block_reason = media_url_block_reason(probe_url)
        if block_reason:
            return cors_response(
                {"error": describe_media_url_block(block_reason), "code": block_reason},
                400,
            )

        raw_cookies = body.get('cookies')
        cookies_text = body.get('cookiesText')
        username = body.get('username')
        password = body.get('password')
        has_credentials = username is not None or password is not None
        has_cookies = (
            isinstance(raw_cookies, list)
            or isinstance(cookies_text, str)
            or isinstance(body.get('browser'), str)
        )
        if has_credentials and has_cookies:
            return cors_response({
                "error": "Provide either username/password or cookies, not both.",
                "code": "ambiguous-site-login",
            }, 400)
        if has_credentials:
            if not isinstance(username, str) or not isinstance(password, str):
                return cors_response({
                    "error": "Username and password are both required.",
                    "code": "missing-credentials",
                }, 400)
            result, error = store.save_credentials(
                body['site'], username, password,
                source=str(body.get('source') or 'credentials')[:60],
            )
        elif isinstance(raw_cookies, list):
            result, error = store.save_cookies(
                body['site'], raw_cookies[:MAX_SITE_LOGIN_COOKIES],
                source=str(body.get('source') or 'extension')[:60],
            )
        elif isinstance(cookies_text, str):
            result, error = store.import_netscape_text(
                body['site'], cookies_text,
                source=str(body.get('source') or 'cookies.txt')[:60],
            )
        elif isinstance(body.get('browser'), str):
            result, error = dl_manager.import_site_login_from_browser(
                body['site'], body['browser'], body.get('profile'),
            )
        else:
            return cors_response({
                "error": "Provide username/password, cookies, cookiesText, or a browser to read them from.",
                "code": "missing-cookies",
            }, 400)
        if error:
            return cors_response({"error": error, "code": "site-login-failed"}, 400)
        payload = dict(result or {})
        warning_claim = None
        if is_youtube_url(probe_url):
            with youtube_sign_in_warning_lock:
                if (not youtube_sign_in_warning_delivered
                        and not config.get("YouTubeSignInRiskNoticeShown", False)):
                    persisted = bool(config.update({
                        "YouTubeSignInRiskNoticeShown": True
                    }))
                    youtube_sign_in_warning_delivered = True
                    warning_claim = persisted
        if warning_claim is not None:
            payload.update({
                "warningCode": _YOUTUBE_SIGN_IN_WARNING_CODE,
                "warning": _YOUTUBE_SIGN_IN_WARNING,
                "warningUrl": _YOUTUBE_SIGN_IN_WARNING_URL,
                "warningStatePersisted": warning_claim,
            })
            if not warning_claim:
                write_persistent_log(
                    "Could not save the one-time YouTube sign-in warning state."
                )
        return cors_response(payload)


def _register_system_routes(api, context, dependencies):
    """Register health, pairing, configuration, update, and shutdown routes."""
    config = context.config
    dl_manager = context.dl_manager
    subscription_manager = context.subscription_manager
    pickfolder_rate_limiter = context.pickfolder_rate_limiter
    health_rate_limiter = context.health_rate_limiter
    pair_rate_limiter = context.pair_rate_limiter
    companion_update_gate = context.companion_update_gate
    record_companion_update_result = context.record_companion_update_result
    check_auth = context.check_auth
    request_json_object = context.request_json_object
    is_allowed_extension_origin = context.is_allowed_extension_origin
    cors_response = context.cors_response
    APP_NAME = dependencies["APP_NAME"]
    APP_VERSION = dependencies["APP_VERSION"]
    DEFAULT_CONFIG = dependencies["DEFAULT_CONFIG"]
    RATE_LIMIT_DOWNLOAD_MAX = dependencies["RATE_LIMIT_DOWNLOAD_MAX"]
    RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS = dependencies["RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS"]
    RATE_LIMIT_HEALTH_MAX = dependencies["RATE_LIMIT_HEALTH_MAX"]
    RATE_LIMIT_HEALTH_WINDOW_SECONDS = dependencies["RATE_LIMIT_HEALTH_WINDOW_SECONDS"]
    SERVER_PORT = dependencies["SERVER_PORT"]
    SERVICE_API_VERSION = dependencies["SERVICE_API_VERSION"]
    SERVICE_API_MINIMUM_CLIENT = dependencies["SERVICE_API_MINIMUM_CLIENT"]
    SERVICE_ID = dependencies["SERVICE_ID"]
    YTDLP_PATH = dependencies["YTDLP_PATH"]
    _folder_pick_q = dependencies["_folder_pick_q"]
    _folder_picker_service = dependencies["_folder_picker_service"]
    _run_companion_self_update = dependencies["_run_companion_self_update"]
    _run_ytdlp_self_update = dependencies["_run_ytdlp_self_update"]
    allowed_output_roots = dependencies["allowed_output_roots"]
    clamp_int = dependencies["clamp_int"]
    clean_text = dependencies["clean_text"]
    coerce_bool = dependencies["coerce_bool"]
    get_ffmpeg_version = dependencies["get_ffmpeg_version"]
    get_last_deno_provision_error = dependencies["get_last_deno_provision_error"]
    get_recent_log_entries = dependencies["get_recent_log_entries"]
    get_ytdlp_version = dependencies["get_ytdlp_version"]
    evaluate_sabr_support = dependencies["evaluate_sabr_support"]
    evaluate_preflight_checks = dependencies["evaluate_preflight_checks"]
    get_preflight_ffmpeg_capabilities = dependencies["get_preflight_ffmpeg_capabilities"]
    get_preflight_output_folder = dependencies["get_preflight_output_folder"]
    get_preflight_state_location = dependencies["get_preflight_state_location"]
    get_system_clock_state = dependencies["get_system_clock_state"]
    get_github_api_budget = dependencies["get_github_api_budget"]
    normalize_extension_origin = dependencies["normalize_extension_origin"]
    is_extension_origin_shape = dependencies["is_extension_origin_shape"]
    is_paired_extension_origin = context.is_paired_extension_origin
    compute_endpoint_proof = dependencies["compute_endpoint_proof"]
    pair_browser_extension = dependencies["pair_browser_extension"]
    probe_javascript_runtime = dependencies["probe_javascript_runtime"]
    probe_po_token_provider = dependencies["probe_po_token_provider"]
    provision_deno = dependencies["provision_deno"]
    read_update_recovery_status = dependencies["read_update_recovery_status"]

    @api.route('/health')
    def health():
        token = config.get("ServerToken")
        legacy_health_token_echo = coerce_bool(
            config.get("LegacyHealthTokenEcho", DEFAULT_CONFIG["LegacyHealthTokenEcho"]),
            DEFAULT_CONFIG["LegacyHealthTokenEcho"],
        )
        # A paired extension can already read this token over the native
        # channel, so the bearer handshake must not stall when native
        # messaging is unavailable (enterprise policy, unpacked installs,
        # or a browser that has not reloaded the host manifest yet).
        paired_origin = is_paired_extension_origin(request.headers.get("Origin", ""))
        token_reachable = legacy_health_token_echo or paired_origin
        allowed, retry_after = health_rate_limiter.allow('health')
        if not allowed:
            return cors_response(
                {"error": "Too many health requests in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        runtime_status = _public_runtime_status(probe_javascript_runtime(
            configured_runtime=config.get('JavaScriptRuntime', 'auto')
        ))
        ytdlp_version = get_ytdlp_version()
        ffmpeg_version = get_ffmpeg_version()
        po_token_provider = probe_po_token_provider()
        ffmpeg_capabilities = get_preflight_ffmpeg_capabilities()
        resp = {
            "status": "ok", "service": SERVICE_ID, "api": SERVICE_API_VERSION,
            "minimumClientApi": SERVICE_API_MINIMUM_CLIENT,
            "name": APP_NAME, "version": APP_VERSION,
            "port": clamp_int(config.get("ServerPort", SERVER_PORT), SERVER_PORT, 1024, 65535),
            "downloads": dl_manager.active_count(),
            "queue": dl_manager.capacity(),
            "token_required": True,
            "legacyTokenEcho": legacy_health_token_echo,
            "paired": paired_origin,
            "nativeChannelRequired": not token_reachable,
            # v1.2.0: surface tool versions so the extension can show
            # "yt-dlp 2026.04.01" in the repair panel + warn on stale binaries.
            "ytDlpVersion": ytdlp_version,
            "ffmpegVersion": ffmpeg_version,
            # v1.4.0 (N1): retain the field for extension wire compatibility.
            # The companion disables yt-dlp plugin loading, so this remains
            # null and is never reported as a usable download provider.
            "poTokenProvider": po_token_provider,
            # v1.4.0 (NX10): bundled ffmpeg freshness audit. The extension
            # popup can surface a "ffmpeg looks stale (X.x); update via
            # the Repair panel" pill when current=false. null = first-run
            # bootstrap before ffmpeg is on disk.
            "ffmpegCapabilities": ffmpeg_capabilities,
            # External JavaScript runtime capability. The legacy denoRuntime
            # key remains during the additive migration to javascriptRuntime.
            "denoRuntime": runtime_status,
            "javascriptRuntime": runtime_status,
            # Verified updater state contains only versions/status codes; file
            # paths and digests remain local to the companion.
            "updateRecovery": read_update_recovery_status(),
            # v1.6.0: SABR (Server-Based Adaptive Bitrate) support status.
            # YouTube's web client now returns SABR-only streaming URLs for
            # a growing share of videos. yt-dlp PR #13515 adds native SABR
            # download support but is still in draft. Until it merges, the
            # companion passes formats=duplicate which surfaces both HTTPS
            # and SABR entries, but SABR entries cannot be downloaded. The
            # extension health panel surfaces "SABR: limited" when native
            # support is absent, so users understand why some downloads fail.
            "sabrSupport": evaluate_sabr_support(ytdlp_version),
            "rateLimit": {
                "downloadMaxPerWindow": RATE_LIMIT_DOWNLOAD_MAX,
                "downloadWindowSeconds": RATE_LIMIT_DOWNLOAD_WINDOW_SECONDS,
                "healthMaxPerWindow": RATE_LIMIT_HEALTH_MAX,
                "healthWindowSeconds": RATE_LIMIT_HEALTH_WINDOW_SECONDS,
            },
            # Recent log lines can contain absolute paths (usernames), exception
            # text, and download IDs. /health is otherwise unauthenticated (only
            # Host-checked), so only expose diagnostics to a caller holding the
            # bearer token — an unauthenticated local process gets an empty list.
            "recentErrors": get_recent_log_entries() if check_auth() else [],
        }
        try:
            sign_in_entries = dl_manager.site_logins.entries()
        except Exception:
            # The pre-flight has no reason to expose a persistence exception or
            # the names of stored sites. An unavailable index is simply an
            # empty, non-blocking sign-in surface until the GUI can repair it.
            # reason: the pre-flight must not expose a persistence exception or the names of stored sites
            sign_in_entries = []
        try:
            site_refusals = dl_manager.refusing_sites()
        except Exception:
            # reason: the pre-flight must not expose a manager exception or the names of refusing sites
            site_refusals = []
        resp["preflight"] = evaluate_preflight_checks(
            ytdlp_version=ytdlp_version,
            ffmpeg_capabilities=ffmpeg_capabilities,
            javascript_runtime=runtime_status,
            sign_in_entries=sign_in_entries,
            github_api_budget=get_github_api_budget(),
            po_token_provider=po_token_provider,
            output_folder=get_preflight_output_folder(config),
            state_location=get_preflight_state_location(),
            site_refusals=site_refusals,
            system_clock=get_system_clock_state(),
        )
        # The snapshot carries every subscribed channel URL and title, which is
        # a list of what this user follows — the same class of thing as
        # recentErrors above, and gated the same way.
        if subscription_manager is not None and check_auth():
            try:
                resp["subscriptions"] = subscription_manager.snapshot()
            except Exception:
                # Health must remain available if the optional scheduler is
                # recovering from a malformed local state file.
                # reason: health stays available while the optional scheduler recovers from a malformed local state file
                resp["subscriptions"] = {
                    "schedulerRunning": False,
                    "subscriptions": [],
                    "archive": {},
                }
        # Legacy token echo is an explicit compatibility path only. Browser
        # extension origins must be configured first; arbitrary installed
        # extensions must not be able to bootstrap the bearer token.
        origin = request.headers.get("Origin", "")
        token_source = clean_text(request.headers.get("X-MDL-Token-Source", ""), "", 32)
        if token_source:
            resp["tokenSource"] = token_source
        if (
            token_source != "native"
            and request.headers.get("X-MDL-Client") == "MediaDL"
            and (
                paired_origin
                or (legacy_health_token_echo and is_allowed_extension_origin(origin))
            )
        ):
            resp["token"] = token
        return cors_response(resp)

    @api.route('/identity', methods=['GET'])
    def endpoint_identity():
        """Answer Astra Deck's endpoint challenge so cookies may be attached.

        Astra Deck sends the same random challenge over the native channel and
        to this route, then requires both answers to match before it attaches a
        YouTube cookie to a download. A process that squatted a companion port
        and answered /health cannot produce the answer, because the answer is
        keyed by the session token it does not hold.

        Deliberately unauthenticated: the response is an HMAC, so it proves
        possession of the token without disclosing it, and the caller must
        already know a fresh challenge for the answer to be worth anything.
        """
        origin = request.headers.get("Origin", "")
        reflected = normalize_extension_origin(origin) if is_extension_origin_shape(origin) else ""
        challenge = clean_text(
            request.args.get("challenge", "")
            or request.headers.get(ENDPOINT_CHALLENGE_HEADER, ""),
            "", 64,
        ).strip()
        # Compared byte-for-byte against the native channel's answer, so the
        # challenge is opaque here: normalising case would make this route
        # answer inputs the native host refuses, and the two answers would
        # then disagree for the same challenge.
        proof = compute_endpoint_proof(config.get("ServerToken"), challenge)
        if not proof:
            return cors_response({
                "ok": False,
                "service": SERVICE_ID,
                "api": SERVICE_API_VERSION,
                "code": "invalid-challenge",
                "error": "A 32-character hex challenge is required.",
            }, 400, allow_origin=reflected)
        return cors_response({
            "ok": True,
            "service": SERVICE_ID,
            "api": SERVICE_API_VERSION,
            "challengeProof": proof,
        }, allow_origin=reflected)

    @api.route('/pair-extension', methods=['POST'])
    def pair_extension():
        """Let Astra Deck introduce its Chrome/Edge ID over loopback.

        Native messaging cannot start until that ID is in the host manifest.
        This route does not echo the session token; the extension retries the
        native channel after a successful pair.
        """
        origin = request.headers.get("Origin", "")
        reflected = normalize_extension_origin(origin) if is_extension_origin_shape(origin) else ""
        if not reflected:
            return cors_response({
                "ok": False,
                "paired": False,
                "code": "invalid-origin",
                "error": "Pairing is only accepted from the Astra Deck extension.",
            }, 403)
        allowed, retry_after = pair_rate_limiter.allow(reflected)
        if not allowed:
            return cors_response(
                {
                    "ok": False,
                    "paired": False,
                    "code": "rate-limited",
                    "error": "Too many pairing requests. Please wait a moment.",
                },
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
                allow_origin=reflected,
            )
        body, body_error = request_json_object()
        if body_error:
            return cors_response({
                "ok": False,
                "paired": False,
                "code": "invalid-body",
                "error": body_error,
            }, 400, allow_origin=reflected)
        requested_id = clean_text((body or {}).get("id", ""), "", 128)
        result = pair_browser_extension(origin, requested_id)
        status = 200 if result.get("ok") else 403
        if "token" in result:
            result = {k: v for k, v in result.items() if k != "token"}
        return cors_response(result, status, allow_origin=reflected)

    @api.route('/provision-deno', methods=['POST'])
    def provision_deno_endpoint():
        # Constant-time comparison (was a plain != , the only mutating endpoint
        # not using a timing-safe check). Keep the legacy X-MDL-Token header for
        # client compatibility, but also accept the standard X-Auth-Token.
        legacy = request.headers.get('X-MDL-Token', '')
        token = config.get("ServerToken")
        legacy_ok = bool(token and legacy and hmac.compare_digest(str(legacy), str(token)))
        if not (check_auth() or legacy_ok):
            return cors_response({"error": "Unauthorized"}, 403)
        result = provision_deno(config)
        if result:
            runtime = probe_javascript_runtime(
                force=True,
                configured_runtime=config.get('JavaScriptRuntime', 'auto'),
            )
            return cors_response({
                "ok": True,
                "denoRuntime": _public_runtime_status(runtime),
            })
        error = get_last_deno_provision_error()
        return cors_response({
            "ok": False,
            "code": error.get('code') or 'deno-provision-failed',
            "error": error.get('message') or "Failed to download Deno. Check network connection.",
        }, 500)

    @api.route('/config', methods=['GET'])
    def get_config():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        video_path = config.get('DownloadPath', '')
        audio_path = config.get('AudioDownloadPath', '')
        c = {
            'DownloadPath': video_path,
            'AudioDownloadPath': audio_path,
            'videoFormats': ['mp4', 'mkv', 'webm'],
            'audioFormats': ['mp3', 'm4a', 'opus', 'flac', 'wav'],
            'qualities': ['best', '2160', '1440', '1080', '720', '480'],
        }
        # v1.2.2: expose camelCase aliases for the path keys so the extension
        # can use the conventional JS casing. Capital-case keys remain for
        # backward compatibility with older extension builds.
        c['downloadPath'] = video_path
        c['audioDownloadPath'] = audio_path
        return cors_response(c)

    @api.route('/pick-folder', methods=['POST'])
    def pick_folder():
        """v1.2.2: pop a native QFileDialog and return the selected path.

        The extension popup's "Change" button calls this so users don't
        have to manually type a Windows path. Blocks until the dialog is
        accepted or cancelled (up to 120 s); the dialog runs on the GUI
        thread via FolderPickerService.
        """
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        if _folder_picker_service() is None:
            return cors_response({"error": "Folder picker is not available."}, 503)
        allowed, retry_after = pickfolder_rate_limiter.allow('pickfolder')
        if not allowed:
            return cors_response(
                {"error": "Too many folder-picker requests in a short period. Please wait a moment."},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        body, body_error = request_json_object()
        if body_error:
            return cors_response({"error": body_error, "code": "invalid-request-body"}, 400)
        initial = clean_text(body.get('initial'), '', 1024)
        response_q = queue.Queue(maxsize=1)
        cancellation = threading.Event()
        pick_request = {
            'initial': initial,
            'response': response_q,
            'cancelled': cancellation,
        }
        try:
            _folder_pick_q.put_nowait(pick_request)
        except queue.Full:
            return cors_response({"error": "A folder picker is already open. Close it before requesting another."}, 409)
        try:
            result = response_q.get(timeout=120)
        except queue.Empty:
            # The GUI thread may still be busy with an earlier native dialog.
            # Mark this queued request so its eventual dequeue is discarded
            # instead of opening a ghost dialog after this HTTP call ended.
            cancellation.set()
            return cors_response({
                "error": "Folder picker timed out. Close the open folder dialog, then retry."
            }, 504)
        if isinstance(result, dict) and result.get('path'):
            roots = allowed_output_roots(config)
            inside = False
            try:
                rp = Path(result['path']).resolve()
                for root in roots:
                    try:
                        rp.relative_to(root)
                        inside = True
                        break
                    except ValueError:
                        continue
            except (OSError, RuntimeError, TypeError, ValueError):
                # The hint is advisory, but an indeterminate path must not be
                # represented as trusted. /download independently enforces it.
                inside = False
            result['outsideAllowlist'] = not inside
        return cors_response(result)

    @api.route('/update-ytdlp', methods=['POST'])
    def update_ytdlp():
        """v4.47.0 NF18: on-demand ``yt-dlp -U`` so a user can fix a
        broken-on-YouTube yt-dlp build without waiting up to 24 h for
        the auto-update throttle (NF26).

        Gates:
        - 401 when the per-install token doesn't match.
        - 409 when at least one download is in flight; the user-visible
          error explains the reason. yt-dlp's ``-U`` atomically replaces
          the binary, and on Windows an in-flight
          ``subprocess.Popen([YTDLP_PATH, ...])`` can race the replace
          with a file-in-use error.
        - 503 when yt-dlp.exe is not present.

        Returns the structured result from ``_run_ytdlp_self_update``
        so the popup can show ``version_before -> version_after`` and
        the exit code on failure.
        """
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        if not YTDLP_PATH.exists():
            return cors_response({
                "error": "yt-dlp is not installed yet. Finish the Astra Downloader setup first.",
                "ok": False,
            }, 503)
        in_flight = dl_manager.active_count()
        if in_flight > 0:
            active_downloads = (
                f"{in_flight} download is"
                if in_flight == 1
                else f"{in_flight} downloads are"
            )
            return cors_response(
                {
                    "error": f"{active_downloads} still in flight. Wait for them to finish, then try again. "
                             f"yt-dlp -U atomically replaces the binary and would race the active subprocess.",
                    "ok": False,
                    "inFlight": in_flight,
                },
                409,
            )
        result = _run_ytdlp_self_update(config, source_tag='manual')
        # 200 with ok:true on success; 500 with ok:false otherwise so the
        # popup can branch on HTTP status as well as the body field.
        status = 200 if result.get('ok') else 500
        return cors_response(result, status)

    @api.route('/update', methods=['POST'])
    def update_companion():
        """v4.47.0 NF6: update the Astra Downloader companion itself.

        This is separate from /update-ytdlp. It compares the running
        APP_VERSION to the canonical repo source, downloads the latest
        AstraDownloader.exe into the managed install directory, schedules an
        after-exit atomic replace, then exits so the helper can relaunch the
        new companion. Active downloads block the update because a restart
        would terminate their yt-dlp subprocesses.
        """
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        allowed, retry_after, gate_code = companion_update_gate()
        if not allowed:
            message = (
                "The companion updater is backing off after a failed attempt. "
                "Please wait before trying again."
                if gate_code == 'update-backoff'
                else "Too many companion update requests in a short period. Please wait a moment."
            )
            return cors_response(
                {"error": message, "ok": False, "error_code": gate_code},
                429,
                extra_headers={"Retry-After": str(int(retry_after) + 1)},
            )
        in_flight = dl_manager.active_count()
        if in_flight > 0:
            active_downloads = (
                f"{in_flight} download is"
                if in_flight == 1
                else f"{in_flight} downloads are"
            )
            return cors_response(
                {
                    "error": f"{active_downloads} still in flight. Wait for them to finish, then try again. "
                             f"The companion update must restart Astra Downloader after atomically replacing the executable.",
                    "ok": False,
                    "inFlight": in_flight,
                },
                409,
            )
        result = _run_companion_self_update(restart=True, dl_manager=dl_manager)
        record_companion_update_result(result)
        if result.get('ok'):
            return cors_response(result, 200)
        if result.get('error_code') == 'downloads-in-flight':
            # A download slipped in on another waitress thread during the
            # update download/verify window; the pre-restart re-check aborted
            # before os._exit(0) could orphan its yt-dlp tree. Same 409
            # contract as the entry check above.
            return cors_response(result, 409)
        status = 502 if result.get('error_code') == 'version-check-failed' else 500
        return cors_response(result, status)

    @api.route('/shutdown', methods=['POST'])
    def shutdown():
        if not check_auth():
            return cors_response({"error": "Astra Downloader rejected the request. Refresh the private token in Astra Deck."}, 401)
        # Waitress has no in-handler shutdown hook (and werkzeug's was removed
        # in 2.1). The GUI's _stop_server() is the authoritative kill path;
        # this endpoint exists so the extension can *request* teardown and
        # know whether the app-level path must be used instead.
        func = request.environ.get('werkzeug.server.shutdown')
        if func:
            func()
            return cors_response({"status": "shutting_down"})
        return cors_response({"status": "stop_from_app_required"}, 202)


# ══════════════════════════════════════════════════════════════
# FIRST-RUN SETUP
# ══════════════════════════════════════════════════════════════


def __getattr__(name):
    return _resolve_legacy(name)


def __dir__():
    return sorted((*globals(), *__all__))
